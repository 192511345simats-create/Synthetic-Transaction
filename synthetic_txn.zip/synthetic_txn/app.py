import os, io, csv, json, sqlite3
from functools import wraps
from flask import Flask, g, render_template, request, redirect, session, jsonify, abort, Response
from werkzeug.security import check_password_hash
import sim

def create_app(db_path="synthetic.db", data_path=sim.DATA):
    app = Flask(__name__); app.secret_key = os.environ.get("SECRET_KEY","dev-change-me"); app.config["DB"] = db_path
    with sqlite3.connect(db_path) as c: sim.init_db(c, data_path)
    def db():
        if "db" not in g: g.db = sqlite3.connect(app.config["DB"]); g.db.row_factory = sqlite3.Row
        return g.db
    @app.teardown_appcontext
    def _close(_): 
        d = g.pop("db", None)
        if d: d.close()
    def need(role):
        def deco(f):
            @wraps(f)
            def w(*a, **k):
                if "user" not in session: return redirect("/login")
                if session["role"] != role: abort(403)
                return f(*a, **k)
            return w
        return deco
    def audit(ev): db().execute("INSERT INTO audit_logs(ts,user,event) VALUES(?,?,?)",(sim.now(),session.get("user","anon"),ev)); db().commit()

    @app.route("/")
    def index(): return render_template("index.html")
    @app.route("/login", methods=["GET","POST"])
    def login():
        err = None
        if request.method == "POST":
            u = db().execute("SELECT * FROM users WHERE user_id=?",(request.form.get("user_id","").strip(),)).fetchone()
            if u and check_password_hash(u["password_hash"], request.form.get("password","")) and u["role"] == request.form.get("role"):
                session.clear(); session.update(user=u["user_id"], role=u["role"]); audit("login ok")
                return redirect("/admin" if u["role"]=="admin" else "/customer")
            err = "Invalid user ID, password or role"; audit(f"login failed for '{request.form.get('user_id','')[:30]}'")
        return render_template("login.html", err=err)
    @app.route("/logout")
    def logout(): session.clear(); return redirect("/")
    @app.route("/admin")
    @need("admin")
    def admin(): return render_template("admin.html", user=session["user"])
    @app.route("/customer")
    @need("customer")
    def customer(): return render_template("customer.html", user=session["user"])

    @app.route("/api/run", methods=["POST"])
    @need("admin")
    def run():
        tid = sim.run_simulation(db(), user=session["user"]); return jsonify(sim.get_report(db(), tid))
    @app.route("/api/stats")
    @need("admin")
    def stats():
        q = lambda s: db().execute(s).fetchone()[0]
        t = "FROM transactions WHERE source='simulation'"
        return jsonify(total=q(f"SELECT COUNT(*) {t}"), success=q(f"SELECT COUNT(*) {t} AND final_status='SUCCESS'"),
          recovered=q(f"SELECT COUNT(*) {t} AND final_status='RECOVERED'"), failed=q(f"SELECT COUNT(*) {t} AND final_status='FAILED_ESCALATED'"),
          unresolved=q("SELECT COUNT(*) FROM incidents WHERE status='ESCALATED'"), successful_recoveries=q("SELECT COUNT(*) FROM incidents WHERE status='RESOLVED'"),
          avg_ms=round(q(f"SELECT COALESCE(AVG(total_ms),0) {t}"),1),
          by_stage=[dict(r) for r in db().execute("SELECT stage k,COUNT(*) n FROM incidents WHERE status!='MONITORED' GROUP BY stage")],
          by_category=[dict(r) for r in db().execute("SELECT category k,COUNT(*) n FROM incidents GROUP BY category")],
          dataset=dict(usable=q("SELECT COUNT(*) FROM dataset_orders WHERE status='USABLE'"), cancelled=q("SELECT COUNT(*) FROM dataset_orders WHERE status='CANCELLED'")),
          scenarios=q("SELECT COUNT(*) FROM scenarios"), model=sim.models()["metrics"])
    @app.route("/api/transactions")
    @need("admin")
    def txns():
        s = "%"+request.args.get("q","")+"%"
        return jsonify([dict(r) for r in db().execute("SELECT id,invoice_id,scenario_id,total,final_status,total_ms,started FROM transactions WHERE source='simulation' AND (id LIKE ? OR invoice_id LIKE ? OR scenario_id LIKE ? OR final_status LIKE ?) ORDER BY started DESC LIMIT 200",(s,s,s,s))])
    @app.route("/api/incidents")
    @need("admin")
    def incs():
        return jsonify([dict(r) for r in db().execute("SELECT i.id,i.txn_id,i.stage,i.category,i.status,d.cause FROM incidents i JOIN diagnoses d ON d.incident_id=i.id ORDER BY i.id DESC LIMIT 200")])
    @app.route("/api/dataset")
    @need("admin")
    def dataset():
        s = "%"+request.args.get("q","")+"%"; c = request.args.get("country","")
        sql = "SELECT invoice_id,customer_id,country,n_lines,total,status FROM dataset_orders WHERE (invoice_id LIKE ? OR customer_id LIKE ?)"; a = [s,s]
        if c: sql += " AND country=?"; a.append(c)
        return jsonify(rows=[dict(r) for r in db().execute(sql+" ORDER BY invoice_id LIMIT 100",a)], countries=[r[0] for r in db().execute("SELECT DISTINCT country FROM dataset_orders ORDER BY 1")])
    @app.route("/api/products")
    @need("customer")
    def products(): return jsonify([dict(r) for r in db().execute("SELECT * FROM products ORDER BY description")])
    @app.route("/api/customer/order", methods=["POST"])
    @need("customer")
    def order(): return jsonify(sim.customer_order(db(), session["user"], request.get_json(force=True)))
    @app.route("/report/<tid>")
    @need("admin")
    def report(tid):
        r = sim.get_report(db(), tid)
        return render_template("report.html", r=r) if r else abort(404)
    @app.route("/report/<tid>.csv")
    @need("admin")
    def report_csv(tid):
        r = sim.get_report(db(), tid) or abort(404); o = io.StringIO(); w = csv.writer(o)
        t = r["txn"]; w.writerow(["transaction_id","invoice_id","scenario_id","total","final_status","total_ms"]); w.writerow([t["id"],t["invoice_id"],t["scenario_id"],t["total"],t["final_status"],t["total_ms"]])
        w.writerow([]); w.writerow(["stage","status","ms","error_code","timestamp","expected","observed"])
        for s in r["steps"]: w.writerow([s["stage"],s["status"],s["ms"],s["error_code"],s["ts"],s["expected"],s["observed"]])
        for i in r["incidents"]:
            d = i["diagnosis"]; w.writerow([]); w.writerow(["incident",i["stage"],i["category"],i["status"],i["verification"]])
            w.writerow(["evidence"]+i["evidence"]); w.writerow(["cause",d["cause"]]); w.writerow(["solution",d["solution"]]); w.writerow(["reason",d["reason"]])
            for a in i["recovery"]: w.writerow(["recovery",a["action"],a["attempt"],a["result"],a["detail"]])
        return Response(o.getvalue(), mimetype="text/csv", headers={"Content-Disposition":f"attachment; filename={tid}.csv"})
    return app

if __name__ == "__main__":
    create_app().run(debug=False, port=5000)
