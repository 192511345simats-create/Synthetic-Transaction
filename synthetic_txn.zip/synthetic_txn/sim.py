"""Core engine: dataset, scenarios, FSM workflow, diagnosis (rules + Decision Tree), anomaly (IsolationForest),
incident matching (TF-IDF), safe recovery, persistence."""
import os, re, json, random, datetime as dt
import numpy as np, pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from werkzeug.security import generate_password_hash

DATA = os.path.join("data", "Online Retail.xlsx")
STAGES = ["login","product_validation","cart","address","contact","payment","payment_verification","order_placement","confirmation"]
BASE = dict(zip(STAGES,[120,150,90,200,80,400,250,300,180]))
MAX_RETRIES, BACKOFF = 3, 200
TYPES = ["success","invalid_login","product_unavailable","invalid_address","payment_decline","payment_timeout",
         "slow_service","missing_confirmation","intermittent","recovery_fails"]
FAULTS = {"invalid_login":("login",401,"AUTH_401"),"product_unavailable":("product_validation",404,"STOCK_404"),
 "invalid_address":("address",422,"ADDR_422"),"payment_decline":("payment",402,"PAY_402"),
 "payment_timeout":("payment",408,"PAY_TIMEOUT"),"missing_confirmation":("confirmation",204,"CONF_MISSING"),
 "intermittent":(None,503,"HTTP_503"),"recovery_fails":(None,503,"HTTP_503"),"slow_service":(None,200,"SLOW")}
CODE_CAT = {"AUTH_401":"authentication","STOCK_404":"inventory","ADDR_422":"address","PAY_402":"payment_decline",
 "PAY_TIMEOUT":"payment_timeout","CONF_MISSING":"confirmation","HTTP_503":"transient"}
CATS = ["authentication","inventory","address","payment_decline","payment_timeout","confirmation","transient","latency"]
KB = {  # cause, solution, reason, whitelisted action
 "authentication":("Invalid credentials or locked account","Escalate: customer must reset credentials via the approved flow","Retrying a 401 cannot succeed and risks lockout","escalate_credentials"),
 "inventory":("Product out of stock or discontinued","Substitute an equivalent in-stock product and re-validate","Stock check returned 404 for a catalogue item; substitution keeps the order value","substitute_product"),
 "address":("Address failed validation (format/postcode)","Normalise the address and re-validate","422 means the payload was understood but invalid; normalisation fixes format errors","normalize_address"),
 "payment_decline":("Card declined by issuer","Escalate: ask customer for another payment method; never auto-retry a decline","Repeated attempts on a decline can trigger fraud flags","escalate_payment_method"),
 "payment_timeout":("Gateway timed out; charge status unknown","Query payment status by idempotency key BEFORE retrying","A blind retry could double-charge the customer","verify_then_retry_payment"),
 "confirmation":("Order saved but confirmation not emitted","Re-query order status and resend confirmation","Empty 204 after order placement indicates a notification fault, not a lost order","resend_confirmation"),
 "transient":("Transient 503 from a dependent service","Bounded retry with exponential backoff (max 3)","503 is typically temporary; bounded retries limit load","bounded_retry"),
 "latency":("Service degraded (abnormal latency)","Monitor; no automatic action required","Step succeeded; latency is a leading indicator only","none")}
SEED_INCIDENTS = [("payment gateway timeout charge unknown retry","payment_timeout"),("card declined issuer 402","payment_decline"),
 ("503 service unavailable intermittent","transient"),("postcode invalid address 422","address"),
 ("out of stock product 404","inventory"),("login failed 401 wrong password","authentication"),
 ("confirmation email missing 204 empty","confirmation"),("latency slow response degraded","latency")]

def now(): return dt.datetime.now().isoformat(timespec="milliseconds")

# ---------------- dataset ----------------
def load_dataset(path=DATA):
    """Read-only load of the UCI file. Falls back to a clearly-labelled demo frame if the file is absent."""
    if os.path.exists(path):
        df = pd.read_excel(path, engine="openpyxl", dtype={"InvoiceNo":str,"StockCode":str}); src = "UCI Online Retail"
    else:
        r = np.random.default_rng(1); n = 1600
        df = pd.DataFrame({"InvoiceNo":[str(536000+i//4) for i in range(n)],"StockCode":[f"P{r.integers(1,60):03d}" for _ in range(n)],
          "Quantity":r.integers(1,12,n),"UnitPrice":np.round(r.uniform(.5,25,n),2),"CustomerID":r.integers(12000,12400,n).astype(float),
          "Country":r.choice(["United Kingdom","France","Germany","EIRE"],n)})
        df["Description"] = "DEMO ITEM " + df.StockCode; df["InvoiceDate"] = pd.Timestamp("2010-12-01")
        df.loc[::97,"InvoiceNo"] = "C" + df.loc[::97,"InvoiceNo"]; df.loc[::53,"Description"] = np.nan
        src = "DEMO DATA (data/Online Retail.xlsx not found)"
    df = df.dropna(subset=["InvoiceNo","StockCode"]).copy(); df["InvoiceNo"] = df.InvoiceNo.astype(str)
    df["cancelled"] = df.InvoiceNo.str.startswith("C"); df["Description"] = df.Description.fillna("").astype(str).str.strip()
    ok = df[(~df.cancelled)&(df.Quantity>0)&(df.UnitPrice>0)&(df.Description!="")].copy()
    ok["Line"] = ok.Quantity*ok.UnitPrice
    return df, ok, src

SCHEMA = """CREATE TABLE IF NOT EXISTS users(user_id TEXT PRIMARY KEY,password_hash TEXT,role TEXT);
CREATE TABLE IF NOT EXISTS products(stock_code TEXT PRIMARY KEY,description TEXT,price REAL,stock INTEGER);
CREATE TABLE IF NOT EXISTS dataset_orders(invoice_id TEXT PRIMARY KEY,customer_id TEXT,country TEXT,n_lines INTEGER,total REAL,status TEXT,items TEXT);
CREATE TABLE IF NOT EXISTS scenarios(id TEXT PRIMARY KEY,type TEXT,stage TEXT,params TEXT);
CREATE TABLE IF NOT EXISTS transactions(id TEXT PRIMARY KEY,invoice_id TEXT,scenario_id TEXT,total REAL,items TEXT,final_status TEXT,started TEXT,total_ms REAL,charges INTEGER,idempotency_key TEXT,source TEXT);
CREATE TABLE IF NOT EXISTS transaction_steps(id INTEGER PRIMARY KEY AUTOINCREMENT,txn_id TEXT,idx INTEGER,stage TEXT,status TEXT,ms REAL,error_code TEXT,ts TEXT,expected TEXT,observed TEXT);
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,txn_id TEXT,stage TEXT,category TEXT,evidence TEXT,status TEXT,verification TEXT,expected TEXT,observed TEXT,ts TEXT);
CREATE TABLE IF NOT EXISTS diagnoses(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_id INTEGER,cause TEXT,solution TEXT,reason TEXT,rule_cat TEXT,ml_cat TEXT,ml_conf REAL,similar TEXT,explanation TEXT);
CREATE TABLE IF NOT EXISTS recovery_actions(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_id INTEGER,action TEXT,attempt INTEGER,result TEXT,detail TEXT,ts TEXT);
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,ts TEXT,user TEXT,event TEXT);"""

def gen_scenarios(per=12):
    r = random.Random(42); out = []
    for ti, t in enumerate(TYPES):
        for k in range(per):
            stage = FAULTS.get(t,(None,))[0] or r.choice(STAGES)
            p = {"slow_mult":round(r.uniform(5,12),1),"charged":r.random()<.5,"fail_attempts":r.choice([1,2])}
            out.append((f"SC-{ti:02d}-{k:03d}-{t[:6].upper()}",t,stage if t!="success" else "-",json.dumps(p)))
    return out

def init_db(conn, data_path=DATA):
    conn.executescript(SCHEMA)
    if not conn.execute("SELECT 1 FROM users").fetchone():
        conn.executemany("INSERT INTO users VALUES(?,?,?)",[("admin",generate_password_hash("Admin@123"),"admin"),
                         ("customer",generate_password_hash("Customer@123"),"customer")])
    if not conn.execute("SELECT 1 FROM dataset_orders").fetchone():
        df, ok, src = load_dataset(data_path)
        ok["item"] = list(zip(ok.StockCode, ok.Description, ok.Quantity.astype(int), ok.UnitPrice.astype(float)))
        g = ok.groupby("InvoiceNo").agg(customer=("CustomerID","first"),country=("Country","first"),n=("Line","size"),total=("Line","sum"),items=("item",list))
        rows = [(i,"GUEST" if pd.isna(r.customer) else str(int(r.customer)),r.country,int(r.n),round(float(r.total),2),"USABLE",json.dumps(r["items"])) for i,r in g.iterrows()]
        canc = df[df.cancelled].groupby("InvoiceNo").agg(c=("CustomerID","first"),country=("Country","first"),n=("Quantity","size"))
        rows += [(i,"GUEST" if pd.isna(r.c) else str(int(r.c)),r.country,int(r.n),0.0,"CANCELLED","[]") for i,r in canc.iterrows()]
        conn.executemany("INSERT OR IGNORE INTO dataset_orders VALUES(?,?,?,?,?,?,?)",rows)
        top = ok.groupby("StockCode").agg(d=("Description","first"),p=("UnitPrice","median"),n=("Line","size")).nlargest(40,"n")
        r = random.Random(7)
        conn.executemany("INSERT OR IGNORE INTO products VALUES(?,?,?,?)",[(c,x.d,round(float(x.p),2),0 if r.random()<.1 else r.randint(5,200)) for c,x in top.iterrows()])
        conn.execute("INSERT INTO audit_logs(ts,user,event) VALUES(?,?,?)",(now(),"system",f"dataset loaded: {src}, {len(rows)} invoices"))
    if not conn.execute("SELECT 1 FROM scenarios").fetchone():
        conn.executemany("INSERT INTO scenarios VALUES(?,?,?,?)",gen_scenarios())
    conn.commit()

# ---------------- ML ----------------
PROFILE = {"authentication":(0,[401]),"inventory":(1,[404]),"address":(3,[422]),"payment_decline":(5,[402]),
           "payment_timeout":(5,[408,504]),"confirmation":(8,[204]),"transient":(None,[503,502]),"latency":(None,[200])}
def synth(n, seed):
    r = np.random.default_rng(seed); X, y = [], []
    for _ in range(n):
        c = CATS[r.integers(len(CATS))]; s, h = PROFILE[c]
        s = int(r.integers(9)) if s is None else s; http = int(r.choice(h))
        ratio = r.uniform(8,16) if c=="payment_timeout" else r.uniform(3.5,12) if c=="latency" else r.uniform(.8,1.5)
        empty = 1 if c=="confirmation" else 0
        if r.random()<.10: http = int(r.choice([200,500,503]))   # noisy telemetry => realistic, non-trivial metrics
        if r.random()<.08: s = int(r.integers(9))
        if r.random()<.08: ratio *= r.uniform(.5,3)
        if r.random()<.05: empty = 1-empty
        X.append([s,http,ratio,empty]); y.append(c)
    return np.array(X), np.array(y)

_M = {}
def models():
    if _M: return _M
    X, y = synth(4000, 0)   # features are observable telemetry only (stage, http, latency ratio, empty body); label is never a feature
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.25, random_state=0, stratify=y)
    clf = DecisionTreeClassifier(max_depth=6, random_state=0).fit(Xtr, ytr); pred = clf.predict(Xte)
    p, r, f, _ = precision_recall_fscore_support(yte, pred, average="macro", zero_division=0)
    pc = precision_recall_fscore_support(yte, pred, labels=CATS, zero_division=0)
    _M["clf"] = clf
    _M["metrics"] = {"train_size":len(ytr),"test_size":len(yte),"precision_macro":round(p,4),"recall_macro":round(r,4),"f1_macro":round(f,4),
        "accuracy":round(float((pred==yte).mean()),4),"labels":CATS,"confusion_matrix":confusion_matrix(yte,pred,labels=CATS).tolist(),
        "per_class":{c:{"precision":round(pc[0][i],3),"recall":round(pc[1][i],3),"f1":round(pc[2][i],3),"support":int(pc[3][i])} for i,c in enumerate(CATS)}}
    rr = np.random.default_rng(3)
    Xn = np.array([[i, BASE[s]*rr.uniform(.8,1.3)] for i,s in enumerate(STAGES) for _ in range(300)])
    _M["iso"] = IsolationForest(contamination=.01, random_state=0).fit(Xn)
    return _M

def is_anomalous(stage, ms):
    return models()["iso"].predict([[STAGES.index(stage), ms]])[0] == -1 and ms/BASE[stage] > 2.5

def match_incident(text, past):
    docs = [t for t,_ in SEED_INCIDENTS] + past
    try:
        v = TfidfVectorizer().fit(docs + [text]); s = cosine_similarity(v.transform([text]), v.transform(docs))[0]
        i = int(s.argmax()); return docs[i], round(float(s[i]),3)
    except Exception: return "none", 0.0

# ---------------- workflow ----------------
def exec_step(sc, stage, attempt, st, rng):
    p, t = sc["params"], sc["type"]; ms = BASE[stage]*rng.uniform(.8,1.3); http, code, empty = 200, "OK", 0
    if stage == sc["stage"] and not st.get("resolved") and t in FAULTS:
        if t in ("invalid_login","product_unavailable","invalid_address","payment_decline","payment_timeout","missing_confirmation","recovery_fails") \
           or (t=="intermittent" and attempt<=p["fail_attempts"]):
            _, http, code = FAULTS[t]; empty = 1 if t=="missing_confirmation" else 0
            if t=="payment_timeout":
                ms = 5000+rng.uniform(0,800); st["ledger"] = bool(p["charged"]); st["charges"] += 1 if p["charged"] else 0
    if t=="slow_service" and stage==sc["stage"]: ms *= p["slow_mult"]
    ok = code == "OK"
    if ok and stage=="payment": st["charges"] += 1
    return {"ok":ok,"http":http,"code":code,"ms":round(ms,1),"empty":empty}

def recover(action, sc, stage, st, rng, key, items):
    L = []
    if action == "bounded_retry":
        for a in range(2, 2+MAX_RETRIES):
            r = exec_step(sc, stage, a, st, rng)
            L.append(("bounded_retry",a-1,"PASS" if r["ok"] else "FAIL",f"retry {a-1}/{MAX_RETRIES}, backoff {BACKOFF*2**(a-2)}ms, http {r['http']}"))
            if r["ok"]: return True, L, r
        L.append(("escalate",MAX_RETRIES+1,"ESCALATED","retries exhausted; escalated to operations")); return False, L, None
    if action in ("escalate_credentials","escalate_payment_method"):
        L.append((action,1,"ESCALATED","no automatic recovery is safe; human/customer action required")); return False, L, None
    if action == "verify_then_retry_payment":
        L.append(("query_payment_status",1,"PASS",f"idempotency key {key}: charge {'FOUND' if st['ledger'] else 'NOT FOUND'}"))
        if st["ledger"]:
            L.append(("skip_retry",2,"PASS","charge already captured; retry skipped to prevent double charge"))
            return True, L, {"ok":True,"http":200,"code":"OK","ms":250.0,"empty":0}
        st["resolved"] = True; r = exec_step(sc, stage, 2, st, rng)
        L.append(("retry_payment_idempotent",2,"PASS","retry with idempotency key; charges=%d"%st["charges"])); return True, L, r
    st["resolved"] = True; r = exec_step(sc, stage, 2, st, rng)
    detail = {"substitute_product":"replaced item with in-stock alternative","normalize_address":"address normalised (trim/case/postcode format)",
              "resend_confirmation":"order status PLACED verified; confirmation resent idempotently"}[action]
    L.append((action,1,"PASS",detail)); return True, L, r

def run_simulation(conn, scenario_id=None, seed=None, user="admin"):
    conn.row_factory = __import__("sqlite3").Row
    rng = random.Random(seed); M = models()
    o = dict(conn.execute("SELECT * FROM dataset_orders WHERE status='USABLE' ORDER BY RANDOM() LIMIT 1").fetchone())
    q = conn.execute("SELECT * FROM scenarios WHERE id=?",(scenario_id,)) if scenario_id else conn.execute("SELECT * FROM scenarios ORDER BY RANDOM() LIMIT 1")
    sc = dict(q.fetchone()); sc["params"] = json.loads(sc["params"])
    tid = f"TXN-{dt.datetime.now():%Y%m%d%H%M%S%f}"[:26]; key = f"idem-{tid}-payment"
    st = {"charges":0}; steps = []; inc = None; final = "SUCCESS"
    def add(i, stage, status, r, exp, obs): steps.append((tid,i,stage,status,r["ms"],r["code"],now(),exp,obs))
    for i, stage in enumerate(STAGES):    # Finite State Machine: each state advances only on PASS; FAIL -> DIAGNOSE -> RECOVER -> VERIFY
        exp = f"HTTP 200 / OK within {int(BASE[stage]*2.5)}ms"
        if final == "FAILED_ESCALATED":
            add(i,stage,"SKIPPED",{"ms":0,"code":"-"},exp,"not executed (upstream failure unresolved)"); continue
        r = exec_step(sc, stage, 1, st, rng); obs = f"HTTP {r['http']} / {r['code']} in {r['ms']}ms"
        if r["ok"]:
            slow = is_anomalous(stage, r["ms"])
            add(i,stage,"SLOW" if slow else "PASS",r,exp,obs)
            if slow and not inc:
                ratio = r["ms"]/BASE[stage]
                inc = {"stage":stage,"cat":"latency","status":"MONITORED","verif":"Step completed; latency flagged by IsolationForest","exp":exp,"obs":obs,
                       "ev":[f"stage={stage}",f"latency={r['ms']}ms vs baseline {BASE[stage]}ms (x{ratio:.1f})","IsolationForest: anomalous"],
                       "rule":"latency","feat":[i,200,ratio,0],"acts":[("none",1,"NOOP","no automatic action; monitoring")]}
            continue
        ratio = r["ms"]/BASE[stage]; add(i,stage,"FAIL",r,exp,obs)
        ev = [f"stage={stage}",f"http_status={r['http']}",f"error_code={r['code']}",f"latency={r['ms']}ms (x{ratio:.1f} baseline)"]+(["empty response body"] if r["empty"] else [])
        rule = CODE_CAT.get(r["code"]); feat = [i,r["http"],ratio,r["empty"]]
        cat = rule or "latency"; action = KB[cat][3]
        ok, L, rr = recover(action, sc, stage, st, rng, key, None)
        if ok:
            add(i,stage,"RECOVERED",rr,"Recovery verification: stage passes",f"verified: HTTP {rr['http']} / {rr['code']}")
            final = "RECOVERED"; inc = {"stage":stage,"cat":cat,"status":"RESOLVED","verif":"PASS - stage re-verified after recovery","exp":exp,"obs":obs,"ev":ev,"rule":rule,"feat":feat,"acts":L}
        else:
            final = "FAILED_ESCALATED"; inc = {"stage":stage,"cat":cat,"status":"ESCALATED","verif":"FAIL - unresolved, escalated; transaction NOT marked successful","exp":exp,"obs":obs,"ev":ev,"rule":rule,"feat":feat,"acts":L}
    total_ms = round(sum(s[4] for s in steps),1)
    conn.execute("INSERT INTO transactions VALUES(?,?,?,?,?,?,?,?,?,?,?)",(tid,o["invoice_id"],sc["id"],o["total"],o["items"],final,steps[0][6],total_ms,st["charges"],key,"simulation"))
    conn.executemany("INSERT INTO transaction_steps(txn_id,idx,stage,status,ms,error_code,ts,expected,observed) VALUES(?,?,?,?,?,?,?,?,?)",steps)
    if inc:
        pred = M["clf"].predict([inc["feat"]])[0]; conf = float(M["clf"].predict_proba([inc["feat"]]).max())
        cat = inc["rule"] or pred   # rules first for clear errors; Decision Tree otherwise
        cause, sol, why, _ = KB[cat]
        past = [f"{r[0]} {r[1]}" for r in conn.execute("SELECT i.stage||' '||i.category, d.cause FROM incidents i JOIN diagnoses d ON d.incident_id=i.id")]
        sim_txt, sim_sc = match_incident(" ".join(inc["ev"]), past)
        expl = (f"At the {inc['stage'].replace('_',' ')} step the system expected a normal response but saw: {inc['obs']}. Most likely cause: {cause.lower()}. "
                f"Recommended: {sol.lower()}. Outcome: {inc['verif']}.")
        cur = conn.execute("INSERT INTO incidents(txn_id,stage,category,evidence,status,verification,expected,observed,ts) VALUES(?,?,?,?,?,?,?,?,?)",
                (tid,inc["stage"],cat,json.dumps(inc["ev"]),inc["status"],inc["verif"],inc["exp"],inc["obs"],now()))
        iid = cur.lastrowid
        conn.execute("INSERT INTO diagnoses(incident_id,cause,solution,reason,rule_cat,ml_cat,ml_conf,similar,explanation) VALUES(?,?,?,?,?,?,?,?,?)",
                (iid,cause,sol,why,inc["rule"] or "-",pred,round(conf,3),f"{sim_txt} (cosine {sim_sc})",expl))
        conn.executemany("INSERT INTO recovery_actions(incident_id,action,attempt,result,detail,ts) VALUES(?,?,?,?,?,?)",[(iid,a,n,r_,d,now()) for a,n,r_,d in inc["acts"]])
    conn.execute("INSERT INTO audit_logs(ts,user,event) VALUES(?,?,?)",(now(),user,f"simulation {tid} scenario {sc['id']} -> {final}"))
    conn.commit(); return tid

def get_report(conn, tid):
    conn.row_factory = __import__("sqlite3").Row
    t = conn.execute("SELECT * FROM transactions WHERE id=?",(tid,)).fetchone()
    if not t: return None
    sc = conn.execute("SELECT * FROM scenarios WHERE id=?",(t["scenario_id"],)).fetchone()
    steps = [dict(r) for r in conn.execute("SELECT * FROM transaction_steps WHERE txn_id=? ORDER BY id",(tid,))]
    incs = []
    for i in conn.execute("SELECT * FROM incidents WHERE txn_id=?",(tid,)):
        d = dict(i); d["evidence"] = json.loads(d["evidence"])
        d["diagnosis"] = dict(conn.execute("SELECT * FROM diagnoses WHERE incident_id=?",(i["id"],)).fetchone())
        d["recovery"] = [dict(r) for r in conn.execute("SELECT * FROM recovery_actions WHERE incident_id=? ORDER BY id",(i["id"],))]
        incs.append(d)
    return {"txn":dict(t),"scenario":dict(sc) if sc else None,"items":json.loads(t["items"]),"steps":steps,"incidents":incs}

def customer_order(conn, user, p):
    """Customer checkout: real validation + simulated payment (no real money)."""
    conn.row_factory = __import__("sqlite3").Row; steps = []; err = None; total = 0.0; lines = []
    def luhn(n):
        d = [int(c) for c in n][::-1]; return (sum(d[0::2]) + sum(sum(divmod(2*x,10)) for x in d[1::2])) % 10 == 0
    def step(name, ok, msg):
        nonlocal err
        steps.append({"stage":name,"status":"PASS" if ok else "FAIL","detail":msg})
        if not ok and not err: err = f"{name}: {msg}"
    for it in p.get("items",[]):
        r = conn.execute("SELECT * FROM products WHERE stock_code=?",(it.get("code"),)).fetchone(); q = int(it.get("qty",0) or 0)
        if r and 0 < q <= r["stock"]: total += q*r["price"]; lines.append([r["stock_code"],r["description"],q,r["price"]])
        else: step("product_validation",False,f"{it.get('code')} unavailable or bad quantity")
    if not lines and not err: step("cart",False,"cart is empty")
    if not err: step("cart",True,f"{len(lines)} lines, total {total:.2f}")
    a = p.get("address",{}); step("address", bool(a.get("street","").strip() and a.get("city","").strip() and re.fullmatch(r"[A-Za-z0-9 \-]{4,10}",a.get("postcode","").strip())), "street/city/postcode checked")
    c = p.get("contact",{}); step("contact", bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",c.get("email",""))) and bool(re.fullmatch(r"\+?\d{7,15}",c.get("phone","").replace(" ",""))), "email/phone checked")
    card = re.sub(r"\D","",p.get("card","")); pay_ok = len(card)>=12 and luhn(card) and not card.endswith("0002")
    step("payment", pay_ok if not err else False, "SIMULATED payment (no real money)" if pay_ok else "declined/invalid card (simulated)")
    final = "FAILED" if err else "SUCCESS"; tid = f"WEB-{dt.datetime.now():%Y%m%d%H%M%S%f}"[:24]
    if not err:
        conn.executemany("UPDATE products SET stock=stock-? WHERE stock_code=?",[(l[2],l[0]) for l in lines]); step("confirmation",True,f"order {tid} placed")
    conn.execute("INSERT INTO transactions VALUES(?,?,?,?,?,?,?,?,?,?,?)",(tid,tid,None,round(total,2),json.dumps(lines),final,now(),0,1 if not err else 0,f"idem-{tid}","customer:"+user))
    conn.executemany("INSERT INTO transaction_steps(txn_id,idx,stage,status,ms,error_code,ts,expected,observed) VALUES(?,?,?,?,?,?,?,?,?)",
        [(tid,i,s["stage"],s["status"],0,"OK" if s["status"]=="PASS" else "VALIDATION",now(),"valid",s["detail"]) for i,s in enumerate(steps)])
    conn.commit(); return {"id":tid,"status":final,"total":round(total,2),"error":err,"steps":steps}
