import json, sqlite3, pytest, sim
from app import create_app

@pytest.fixture(scope="module")
def env(tmp_path_factory):
    p = str(tmp_path_factory.mktemp("d")/"t.db"); app = create_app(p, data_path="__missing__.xlsx"); return app, p

def sc(conn, t, **kw):  # pick scenario of type t
    conn.row_factory = sqlite3.Row
    return [r["id"] for r in conn.execute("SELECT id,params FROM scenarios WHERE type=?",(t,)) if all(json.loads(r["params"])[k]==v for k,v in kw.items())][0]

def run(p, t, **kw):
    c = sqlite3.connect(p); tid = sim.run_simulation(c, scenario_id=sc(c,t,**kw), seed=1); r = sim.get_report(c, tid); c.close(); return r

def test_dataset_and_scenarios(env):
    c = sqlite3.connect(env[1])
    assert c.execute("SELECT COUNT(*) FROM dataset_orders WHERE status='USABLE'").fetchone()[0] > 0
    assert c.execute("SELECT COUNT(*) FROM dataset_orders WHERE status='CANCELLED'").fetchone()[0] > 0
    assert c.execute("SELECT COUNT(*) FROM scenarios").fetchone()[0] >= 100

def test_success(env):
    r = run(env[1],"success"); assert r["txn"]["final_status"]=="SUCCESS" and not r["incidents"] and len(r["steps"])==9

@pytest.mark.parametrize("t,final,cat",[("invalid_login","FAILED_ESCALATED","authentication"),("payment_decline","FAILED_ESCALATED","payment_decline"),
  ("recovery_fails","FAILED_ESCALATED","transient"),("product_unavailable","RECOVERED","inventory"),("invalid_address","RECOVERED","address"),
  ("missing_confirmation","RECOVERED","confirmation"),("intermittent","RECOVERED","transient"),("payment_timeout","RECOVERED","payment_timeout")])
def test_failure_scenarios(env,t,final,cat):
    r = run(env[1],t); assert r["txn"]["final_status"]==final; i = r["incidents"][0]
    assert i["category"]==cat and i["diagnosis"]["solution"] and i["recovery"] and i["evidence"]
    assert (i["status"]=="RESOLVED")==(final=="RECOVERED")

def test_unresolved_never_success(env):
    r = run(env[1],"recovery_fails"); assert r["txn"]["final_status"]!="SUCCESS" and any(s["status"]=="SKIPPED" for s in r["steps"])
    assert sum(1 for a in r["incidents"][0]["recovery"] if a["action"]=="bounded_retry")==sim.MAX_RETRIES

@pytest.mark.parametrize("charged",[True,False])
def test_payment_timeout_no_double_charge(env,charged):
    r = run(env[1],"payment_timeout",charged=charged); assert r["txn"]["charges"]==1
    assert r["incidents"][0]["recovery"][0]["action"]=="query_payment_status"  # verify before any retry

def test_slow_service_detected(env):
    r = run(env[1],"slow_service"); assert r["incidents"][0]["category"]=="latency" and any(s["status"]=="SLOW" for s in r["steps"])

def test_model_metrics_real():
    m = sim.models()["metrics"]; assert 0 < m["f1_macro"] <= 1 and sum(map(sum,m["confusion_matrix"]))==m["test_size"]

def test_persistence_and_report_routes(env):
    app,p = env; r = run(p,"intermittent"); c = sqlite3.connect(p)
    assert c.execute("SELECT COUNT(*) FROM transaction_steps WHERE txn_id=?",(r["txn"]["id"],)).fetchone()[0]>=9
    cl = app.test_client(); cl.post("/login",data={"user_id":"admin","password":"Admin@123","role":"admin"})
    assert cl.get("/report/"+r["txn"]["id"]).status_code==200
    assert cl.get(f"/report/{r['txn']['id']}.csv").data.startswith(b"transaction_id")
    assert cl.post("/api/run").status_code==200 and cl.get("/api/stats").json["total"]>=1

def test_access_control(env):
    app,_ = env; anon = app.test_client()
    assert anon.get("/admin").status_code==302 and anon.post("/api/run").status_code==302
    cu = app.test_client(); cu.post("/login",data={"user_id":"customer","password":"Customer@123","role":"customer"})
    assert cu.get("/admin").status_code==403 and cu.post("/api/run").status_code==403 and cu.get("/customer").status_code==200
    assert app.test_client().post("/login",data={"user_id":"admin","password":"bad","role":"admin"}).status_code==200

def test_customer_checkout(env):
    app,_ = env; cu = app.test_client(); cu.post("/login",data={"user_id":"customer","password":"Customer@123","role":"customer"})
    prods = [p for p in cu.get("/api/products").json if p["stock"]>2]
    base = {"items":[{"code":prods[0]["stock_code"],"qty":1}],"address":{"street":"1 High St","city":"Leeds","postcode":"LS1 4AB"},"contact":{"email":"a@b.co","phone":"+441234567890"}}
    assert cu.post("/api/customer/order",json={**base,"card":"4242424242424242"}).json["status"]=="SUCCESS"
    assert cu.post("/api/customer/order",json={**base,"card":"4000000000000002"}).json["status"]=="FAILED"
    assert cu.post("/api/customer/order",json={**base,"address":{},"card":"4242424242424242"}).json["status"]=="FAILED"
