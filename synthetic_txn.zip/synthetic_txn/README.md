# Synthetic Business Transactions — Autonomous Transaction Monitoring & Recovery

## Windows setup (PowerShell, in VS Code terminal)
```
cd synthetic_txn
py -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
```
Place the UCI file at `data\Online Retail.xlsx` (download: https://archive.ics.uci.edu/dataset/352/online+retail). It is only read, never modified.
If it is missing, the app starts on a clearly labelled DEMO frame (see audit_logs) so everything still runs.

## Run
```
python app.py
```
Open http://127.0.0.1:5000 . The SQLite DB (`synthetic.db`) is created and seeded on first start (delete it to re-initialise, e.g. after adding the xlsx).
Logins: **admin / Admin@123** (role Admin) · **customer / Customer@123** (role Customer). Change `SECRET_KEY` env var for real use.

## Tests
```
python -m pytest -q
```
## Layout
`sim.py` holds dataset loading, FSM workflow, rule diagnosis, Decision Tree, IsolationForest, TF-IDF incident matching, safe recovery, persistence and reports; `app.py` holds routes/auth/API; `templates/`, `static/`, `tests/`.
Optional: save Chart.js as `static/chart.min.js` for fully offline charts (otherwise CDN; tables/numbers work offline regardless).
